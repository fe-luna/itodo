export interface User {
  username: string;
  sub: string;
  email: string;
}
