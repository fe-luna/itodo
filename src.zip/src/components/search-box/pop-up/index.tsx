
import './style.scss'
function PopUp() {
    return (
        <div className="search-popup">popup</div>
    )
}

export default PopUp